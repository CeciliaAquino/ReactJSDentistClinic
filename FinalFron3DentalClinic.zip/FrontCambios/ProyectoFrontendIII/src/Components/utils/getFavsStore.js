const getFavsStore = () => JSON.parse(localStorage.getItem('favs'));

export default getFavsStore;
